﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace GradeDisplay
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //answers as constants later?
        List<String> answerList = new List<string> { "B", "D", "A", "A", "C", "A", "B", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "B", "D", "A" };
        List<String> studentList = new List<string> { };
        List<String> incorrectList = new List <string> { };
        int correct = 0;
        int incorrect = 0;
        public MainWindow()
        {
            InitializeComponent();
            FileReader();
            GradeCheck();
            Display();
        }
        private void FileReader()
        {
            StreamReader reader = new StreamReader(new FileStream("grades.txt", FileMode.OpenOrCreate, FileAccess.Read));
            //Peek checks each line of the file one by one and will return -1 when it reaches the end 
            while (reader.Peek() != -1)
            {
                studentList.Add(reader.ReadLine());
            }
        }

        private void GradeCheck()
        {
            try
            {
                for (int i = 0; i < studentList.Count; i++)
                {
                    if (answerList[i] == studentList[i])
                    {
                        correct++;
                    }
                    else
                    {
                        incorrect++;
                        incorrectList.Add((i + 1) + ". " + studentList[i]);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Invalid student grade file");
            }
        }

        private void Display()
        {
            if (correct >= 15)
            {
                tblPassFail.Text = "The Student Passed";
            }
            else
            {
                tblPassFail.Text = "The Student Failed";
            }
            tblCorrect.Text = "# of Correct Answers: " + correct.ToString();
            tblIncorrect.Text = "# of Incorrect Answers: " + incorrect.ToString();
            for (int i=0; i<incorrectList.Count(); i++)
            {
                lbAnswers.Items.Add(incorrectList[i]);
            }
        }
    }
}
